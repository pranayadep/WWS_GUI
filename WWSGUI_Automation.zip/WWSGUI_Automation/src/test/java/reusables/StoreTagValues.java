package reusables;

public class StoreTagValues {

	public static void getXMLValandStore(String xmlPath) {
		try {

		} catch (Exception e) {
			e.getMessage();
		}
	}

}
