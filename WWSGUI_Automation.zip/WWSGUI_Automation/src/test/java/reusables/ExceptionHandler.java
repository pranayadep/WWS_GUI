package reusables;

public class ExceptionHandler {

	public static void Exception(Exception e){
		
	}
}
